"Discovering key concepts in verbose queries" (annotations)

This tar.gz file contains the following files

1)

====
all.nps ---- contains all the noun-phrases extracted from TREC description queries from ROBUST04,WT10g and GOV2 datasets
w10g.nps --- key noun phrases for w10g collection (one NP per query)
gov2.nps --- key noun phrases for gov2 collection (one NP per query)
rob04.nps --- key noun phrases for rob04 collection (one NP per query)
====

For each query, there is ONE key noun phrase ("key concept") from the list of extracted noun phrases (all.nps). The annotator is given the actual query, the list of NP�s and he/she is allowed to use any external source of information to determine the key concept. The noun phrase extraction is done using montylingua parser: http://web.media.mit.edu/~hugo/montylingua/

2) 

===
query_desc_nps_2_*.txt --- contains structured Indri queries used for the retrieval experiments
===

Each query contains the "bag-of-word" query itself, as well as two highest weighted concepts (noun-phrase) by our concept weighting method. These queries can be run on the corresponding TREC dataset, to reproduce the retrieval results reported in the paper.

For more details, see the original paper: http://ciir.cs.umass.edu/~bemike/new/pubs/2008-2.pdf